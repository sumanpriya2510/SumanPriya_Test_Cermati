package com.Cermati.Tests;

import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.Cermati.Pages.Ebay_Home_Page;
import com.Cermati.Pages.Electronics_Page;
import com.Cermati.Pages.Search_Home_Page;

public class MultipleFilters_Test {
	WebDriver driver;

	@BeforeSuite
	public void launchBrowser() throws Exception {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	@BeforeMethod
	public void launchApplication() {
		driver.navigate().to("https://www.ebay.com");
		driver.manage().window().maximize();
	}
	
	@AfterSuite
	public void cleanup() {
		driver.quit();
	}

	@Test
	public void accessProductViaMultipleFilter() {
		Ebay_Home_Page ebayHomePage = new Ebay_Home_Page(driver);
		Assert.assertTrue(ebayHomePage.isHomePageLoaded());
		ebayHomePage.clickShopByCategory();
		Electronics_Page electronic_page = ebayHomePage.clickCellPhones();
		electronic_page.clickCellPhones_SmartPhones();
		electronic_page.clickSeeAll();
		electronic_page.clickScreenSize();
		electronic_page.clickSelectScreenSize();
		electronic_page.clickPrice();
		electronic_page.fromPrice(100);
		electronic_page.toPrice(500);
		electronic_page.clickItemLocation();
		electronic_page.clickSelectItemLocation();
		electronic_page.clickApply();
		electronic_page.clickFiltersApplied();
		ArrayList<String> filter_text = electronic_page.getFilterElement_Text();
		Assert.assertTrue(filter_text.get(0).contains("Screen Size"));
		Assert.assertTrue(filter_text.get(1).contains("Price"));
		Assert.assertTrue(filter_text.get(2).contains("Item Location"));
	}
	
	@Test
	public void accessProductViaSearch() {
		Search_Home_Page searchHomePage = new Search_Home_Page(driver);
		searchHomePage.sendSearchKey();
		searchHomePage.clickAllCategory();
		searchHomePage.clickSelectCategory();
		searchHomePage.clicksearchButton();
		String productName = searchHomePage.firstProductName();
		Assert.assertTrue(productName.contains("MacBook"));
		
	}

	
	
	
	
}
