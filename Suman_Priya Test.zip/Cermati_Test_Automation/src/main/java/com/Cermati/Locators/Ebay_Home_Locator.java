package com.Cermati.Locators;

import org.openqa.selenium.By;

public class Ebay_Home_Locator  {
	
	public By logoEbay = By.xpath("//img[@alt='eBay Logo']");
	public By shopByCategory = By.id("gh-shop-a");
	public By cellPhones = By.xpath("//a[text()='Cell phones & accessories']");
   

}
