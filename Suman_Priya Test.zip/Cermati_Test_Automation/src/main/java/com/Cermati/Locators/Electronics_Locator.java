package com.Cermati.Locators;

import org.openqa.selenium.By;

public class Electronics_Locator {
	
	public By cellPhones_SmartPhones = By.xpath("//a[text()='Cell Phones & Smartphones']");
	public By seeAll = By.xpath("//span[text()='- Shop by Brand']/..//span[text()='See All']");
	public By screenSize = By.xpath("//span[text()='Screen Size']");
	public By selectScreenSize = By.xpath("//legend[text()='Screen Size']/ancestor::div[contains(@class,'x-overlay-sub-panel')]//span[text()='Not Specified']");
	public By price = By.xpath("//div[@data-aspecttitle='price']");
	public By fromPrice = By.xpath("//input[@aria-label='Minimum Value, US Dollar']");
	public By toPrice = By.xpath("//input[@aria-label='Maximum Value, US Dollar']");
	public By itemLocation = By.xpath("//span[text()='Item Location']");
	public By selectItemLocation = By.xpath("//input[@value='Worldwide']");
	public By apply = By.xpath("//button[@aria-label='Apply']");
	public By filtersApplied = By.xpath("//span[contains(text(),'filters applied')]");
	public By filterElement = By.xpath("//span[contains(text(),'filters applied')]/ancestor::div[contains(@class,'x-flyout brm')]//span[contains(@class,'brm__item')]");
    
    
    
}
