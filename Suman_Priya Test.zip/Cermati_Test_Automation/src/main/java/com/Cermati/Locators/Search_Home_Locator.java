package com.Cermati.Locators;

import org.openqa.selenium.By;

public class Search_Home_Locator {
	
	public By search = By.xpath("//input[@aria-label='Search for anything']");
	public By allCategory = By.id("gh-cat-box");
	public By selectCategory = By.xpath("//option[text()='Computers/Tablets & Networking']");
    public By searchButton = By.xpath("//input[@type='submit']");
	public By firstProduct = By.xpath("//span[contains(text(),'MacBook')]/ancestor::li[@data-view='mi:1686|iid:1']");
	
}
