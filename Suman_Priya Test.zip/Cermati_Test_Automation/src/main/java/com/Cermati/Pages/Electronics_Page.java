package com.Cermati.Pages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.Cermati.Locators.Electronics_Locator;

public class Electronics_Page extends Electronics_Locator{

	WebDriver driver;
	public Electronics_Page(WebDriver driver) {
		
		this.driver=driver;
	}
	
	public void clickCellPhones_SmartPhones() {
		driver.findElement(cellPhones_SmartPhones).click();
	}
	
	public void clickSeeAll() {
		driver.findElement(seeAll).click();
	}
	
	public void clickScreenSize() {
		driver.findElement(screenSize).click();
	}
	
	public void clickSelectScreenSize() {
		driver.findElement(selectScreenSize).click();
	}
	
	public void clickPrice() {
		driver.findElement(price).click();
	}

	public void fromPrice(int from_Price) {
		driver.findElement(fromPrice).sendKeys(String.valueOf(from_Price));
	}
	
	public void toPrice(int to_Price) {
		driver.findElement(toPrice).sendKeys(String.valueOf(to_Price));;
	}
	
	public void clickItemLocation() {
		driver.findElement(itemLocation).click();
	}
	
	public void clickSelectItemLocation() {
		driver.findElement(selectItemLocation).click();
	}
	
	public void clickApply() {
		driver.findElement(apply).click();
	}
	
	public void clickFiltersApplied() {
		driver.findElement(filtersApplied).click();
	}
	
	public ArrayList<String> getFilterElement_Text() {
		List<WebElement> list = driver.findElements(filterElement);
		Iterator<WebElement> iterator = list.iterator();
		ArrayList<String> filterText = new ArrayList<String>();
		while(iterator.hasNext()) {
			String text=iterator.next().getText();
			filterText.add(text);
		}
		return filterText;
	}
	
	
	
}
