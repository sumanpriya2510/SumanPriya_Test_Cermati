package com.Cermati.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.Cermati.Locators.Ebay_Home_Locator;
public class Ebay_Home_Page extends Ebay_Home_Locator {
	WebDriver driver;
	public Ebay_Home_Page(WebDriver driver) {
		
		this.driver=driver;
	}
	
	public boolean isHomePageLoaded() {
		return driver.findElement(logoEbay).isDisplayed();
	}
	
	public void clickShopByCategory() {
		driver.findElement(shopByCategory).click();
	}
	
	public Electronics_Page clickCellPhones() {
		driver.findElement(cellPhones).click();
		return new Electronics_Page(driver);
	}
	

}
