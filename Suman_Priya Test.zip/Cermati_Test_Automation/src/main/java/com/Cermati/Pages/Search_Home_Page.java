package com.Cermati.Pages;

import org.openqa.selenium.WebDriver;

import com.Cermati.Locators.Search_Home_Locator;

public class Search_Home_Page extends Search_Home_Locator {
	
	WebDriver driver;
	public Search_Home_Page (WebDriver driver) {
		
		this.driver=driver;
	}
	
	public void sendSearchKey() {
		driver.findElement(search).sendKeys("MacBook");
		
	}
	
	public void clickAllCategory(){
		driver.findElement(allCategory).click();
	}
	
	public void clickSelectCategory() {
		driver.findElement(selectCategory).click();
	}
	
	public void clicksearchButton() {
	    driver.findElement(searchButton).click();
	}
	
	public String firstProductName() {
		
		String str = driver.findElement(firstProduct).getText();
		return str;
	}
	

}
